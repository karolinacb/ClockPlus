package app.example.karolinabeltran.clockfragment;


import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;


/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {


        public HomeFragment(){

        }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());

        Calendar time = Calendar.getInstance();
        String currentTime = SimpleDateFormat.getTimeInstance(DateFormat.SHORT).format(time.getTime());

        View v = inflater.inflate(R.layout.fragment_home, container, false);
        TextView textViewDate = (TextView) v.findViewById(R.id.text_view_date);
        TextView textViewTime = (TextView) v.findViewById(R.id.text_view_time);

        textViewDate.setText(currentDate);
        textViewTime.setText(currentTime);


        return v;
        }

}